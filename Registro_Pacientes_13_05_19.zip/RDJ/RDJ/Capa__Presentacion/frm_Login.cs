﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace RDJ
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        SqlConnection cn = new SqlConnection("Data Source=DESKTOP-IJ06IBR;Initial Catalog=rdj;Integrated Security=True");

        public void login(string usuario, string password) {
            try
            {
                cn.Open();
                SqlCommand cmd = new SqlCommand("SELECT num_usuario,tipo_usuario FROM usuarios WHERE nombre_usuario = '" + usuario + "' AND pass_usuario = '" + password + "'", cn);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);

                if (dt.Rows.Count == 1)
                {
                    this.Hide();
                    if (dt.Rows[0][1].ToString() == "Administrador")
                    {
                        frm_Usuarios frmUsuarios = new frm_Usuarios();
                        frmUsuarios.Show();
                    }
                    else if (dt.Rows[0][1].ToString() == "Odontologo")
                    {
                        frm_RP_Odonto Odonto = new frm_RP_Odonto();
                        Odonto.Show();
                    }
                    else if (dt.Rows[0][1].ToString() == "MGeneral")
                    {
                        frm_RP_General MGeneral = new frm_RP_General();
                        MGeneral.Show();
                    }
                    else {
                        MessageBox.Show("Error");
                    }
                }
            }
            finally
            {
                cn.Close();
            }
        }

        //Ingresar con boton Ingresar
        private void BtnIngresar_Click(object sender, EventArgs e)
        {
            login(txtUsuario.Text, txtPassword.Text);
        }
        //Ingresar con boton enter
        private void TxtPassword_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                login(txtUsuario.Text, txtPassword.Text);
            }
        }

        //Cancelar 
        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
