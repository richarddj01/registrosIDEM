﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RDJ
{
    public partial class frm_RP_Odonto : Form
    {
        public frm_RP_Odonto()
        {
            InitializeComponent();
        }

        private void Frm_RP_Odonto_Load(object sender, EventArgs e)
        {

        }

        Conexion cn = new Conexion();

        string sexo;

        private void RadioButton1_CheckedChanged(object sender, EventArgs e)
        {
            //Limpiar Textbox
            txt_id_paciente.Clear();
            txt_identidad.Clear();
            txt_nombres.Clear();
            txt_apellidos.Clear();
            txt_direccion.Clear();
            txt_telefono.Clear();
            txt_alergias.Clear();
            //Mostrar Etiquetas (nombres)
            label1.Visible = true;
            label2.Visible = true;
            label3.Visible = true;
            label4.Visible = true;
            label5.Visible = true;
            label6.Visible = true;
            label7.Visible = true;
            label8.Visible = true;
            label10.Visible = true;
            //Mostrar TextBox y RadioButtons
            txt_identidad.Visible = true;
            txt_nombres.Visible = true;
            txt_apellidos.Visible = true;
            radioButton4.Visible = true;
            radioButton5.Visible = true;
            txt_direccion.Visible = true;
            txt_telefono.Visible = true;
            txt_alergias.Visible = true;
            dateTimePicker1.Visible = true;
            txt_id_paciente.Visible = true;
            //Mostrar Botones
            btnRegistrar.Visible = true;
            btnModificar.Visible = false;
            btnEliminar.Visible = false;
            btnBuscar.Visible = false;
            //Activar Casillas
            txt_id_paciente.Enabled = true;
            txt_identidad.Enabled = true;
            txt_nombres.Enabled = true;
            txt_apellidos.Enabled = true;
            txt_direccion.Enabled = true;
            dateTimePicker1.Enabled = true;
            txt_alergias.Enabled = true;
            radioButton4.Enabled = true;
            radioButton5.Enabled = true;
            txt_telefono.Enabled = true;
        }

        private void BtnRegistrar_Click(object sender, EventArgs e)
        {
            if (sexo != "" && txt_id_paciente.Text != "" && txt_alergias.Text != "" && txt_apellidos.Text != "" && txt_direccion.Text != "" && txt_identidad.Text != "" && txt_nombres.Text != "" && txt_telefono.Text != "" && dateTimePicker1.Text != "")
            {
                if (cn.Insertar_Odonto(txt_id_paciente.Text, txt_identidad.Text, txt_nombres.Text, txt_apellidos.Text, sexo, dateTimePicker1.Text, txt_direccion.Text, txt_telefono.Text, txt_alergias.Text))
                {
                    MessageBox.Show("Paciente Ingresado Correctamente");
                    txt_id_paciente.Clear();
                    txt_identidad.Clear();
                    txt_nombres.Clear();
                    txt_apellidos.Clear();
                    txt_direccion.Clear();
                    txt_telefono.Clear();
                    txt_alergias.Clear();
                }
                else
                {
                    MessageBox.Show("Ha ocurrido un error");
                }
            }
            else
            {
                MessageBox.Show("Debe rellenar todos los campos");
            }
        }

        private void RadioButton4_CheckedChanged(object sender, EventArgs e)
        {
            sexo = "Femenino";
        }

        private void RadioButton5_CheckedChanged(object sender, EventArgs e)
        {
            sexo = "Masculino";
        }

        private void BtnModificar_Click(object sender, EventArgs e)
        {
            if (cn.Modificar_Odonto(txt_id_paciente.Text, txt_identidad.Text, txt_nombres.Text, txt_apellidos.Text, sexo, dateTimePicker1.Text, txt_direccion.Text, txt_telefono.Text, txt_alergias.Text))
            {
                MessageBox.Show("Paciente modificado Exitosamente");
            }
            else
            {
                MessageBox.Show("Se ha presentado un error");
            }
        }

        private void RadioButton2_CheckedChanged(object sender, EventArgs e)
        {
            //Mostrar Labels 
            label1.Visible = true;
            label2.Visible = true;
            label3.Visible = true;
            label4.Visible = true;
            label5.Visible = true;
            label6.Visible = true;
            label7.Visible = true;
            label8.Visible = true;
            label10.Visible = true;
            //Mostrar TextBox y RadioButtons
            txt_identidad.Visible = true;
            txt_nombres.Visible = true;
            txt_apellidos.Visible = true;
            radioButton4.Visible = true;
            radioButton5.Visible = true;
            txt_direccion.Visible = true;
            txt_telefono.Visible = true;
            txt_alergias.Visible = true;
            dateTimePicker1.Visible = true;
            txt_id_paciente.Visible = true;
            //Mostrar Botones
            btnRegistrar.Visible = false;
            btnModificar.Visible = true;
            btnEliminar.Visible = false;
            btnBuscar.Visible = true;
            //Activar Casillas
            txt_id_paciente.Enabled = false;
            txt_identidad.Enabled = true;
            txt_nombres.Enabled = false;
            txt_apellidos.Enabled = false;
            txt_direccion.Enabled = true;
            dateTimePicker1.Enabled = true;
            txt_alergias.Enabled = true;
            radioButton4.Enabled = false;
            radioButton5.Enabled = false;
            txt_telefono.Enabled = true;
        }

        private void BtnBuscar_Click(object sender, EventArgs e)
        {
            string[] valores = cn.Buscar_RP_Odonto(txt_identidad.Text);
            txt_id_paciente.Text = valores[0];
            txt_nombres.Text = valores[2];
            txt_apellidos.Text = valores[3];
            if (valores[4] == "Femenino")
            {
                radioButton4.Select();
            }
            else if (valores[4] == "Masculino")
            {
                radioButton5.Select();
            }
            dateTimePicker1.Text = valores[5];
            txt_direccion.Text = valores[6];
            txt_telefono.Text = valores[7];
            txt_alergias.Text = valores[8];

        }

        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            if (cn.Eliminar_Odonto(txt_identidad.Text))
            {
                MessageBox.Show("Usuario Eliminado Correctamente");
            }
            else
            {
                MessageBox.Show("Ha ocurrido un error al intentar eliminar el usuario");
            }
        }

        private void RadioButton3_CheckedChanged(object sender, EventArgs e)
        {
            //Mostrar Labels 
            label1.Visible = true;
            label2.Visible = true;
            label3.Visible = true;
            label4.Visible = true;
            label5.Visible = true;
            label6.Visible = true;
            label7.Visible = true;
            label8.Visible = true;
            label10.Visible = true;
            //Mostrar TextBox y RadioButtons
            txt_identidad.Visible = true;
            txt_nombres.Visible = true;
            txt_apellidos.Visible = true;
            radioButton4.Visible = true;
            radioButton5.Visible = true;
            txt_direccion.Visible = true;
            txt_telefono.Visible = true;
            txt_alergias.Visible = true;
            dateTimePicker1.Visible = true;
            txt_id_paciente.Visible = true;
            //Mostrar Botones
            btnRegistrar.Visible = false;
            btnModificar.Visible = false;
            btnEliminar.Visible = true;
            btnBuscar.Visible = true;
            //Activar Casillas
            txt_id_paciente.Enabled = false;
            txt_identidad.Enabled = true;
            txt_nombres.Enabled = false;
            txt_apellidos.Enabled = false;
            txt_direccion.Enabled = false;
            dateTimePicker1.Enabled = false;
            txt_alergias.Enabled = false;
            radioButton4.Enabled = false;
            radioButton5.Enabled = false;
            txt_telefono.Enabled = false;
        }

        private void Frm_RP_Odonto_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}
