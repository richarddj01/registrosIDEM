﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace RDJ
{
    public partial class frm_Usuarios : Form
    {
        Conexion cn = new Conexion();
        public frm_Usuarios()
        {
            InitializeComponent();
            cn.Nombre_usuario(cmbUsuario);
            cn.tipo_usuario(cmbTipo_usuario);
        }

        private void Frm_Usuarios_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }


        //RadioButton Registrar
        private void RadioButton1_CheckedChanged(object sender, EventArgs e)
        {
            //Limpiar Casillas
            txt_nom_usuario.Clear();
            txt_num_usuario.Clear();
            txt_pass_usuario.Clear();
            //Activar Casillas
            txt_num_usuario.Enabled = true;
            txt_nom_usuario.Enabled = true;
            txt_pass_usuario.Enabled = true;
            cmbTipo_usuario.Enabled = true;
            cmbUsuario.Visible = false;
            //Activar Botones
            btnRegistrar.Visible = true;
            btnModificar.Visible = false;
            btnEliminar.Visible = false;
            cmbUsuario.Visible = false;
            btnRefrescar.Visible = false;
            //Mostrar Textbox y Label
            cmbTipo_usuario.Visible = true;
            txt_nom_usuario.Visible = true;
            txt_num_usuario.Visible = true;
            txt_pass_usuario.Visible = true;
            label1.Visible = true;
            label2.Visible = true;
            label3.Visible = true;
            label4.Visible = true;
        }

        //RadioButton Modificar
        private void RadioButton2_CheckedChanged(object sender, EventArgs e)
        {
            //Limpíar Casillas
            txt_nom_usuario.Clear();
            txt_num_usuario.Clear();
            txt_pass_usuario.Clear();
            //Activar Casillas
            txt_num_usuario.Enabled = false;
            txt_nom_usuario.Enabled = false;
            txt_pass_usuario.Enabled = true;
            cmbTipo_usuario.Enabled = true;
            cmbUsuario.Visible = true;
            //Activar Botones
            btnRegistrar.Visible = false;
            btnModificar.Visible = true;
            btnEliminar.Visible = false;
            cmbUsuario.Enabled = true;
            btnRefrescar.Visible = true;
            //Mostrar Textbox y Label
            cmbTipo_usuario.Visible = true;
            txt_nom_usuario.Visible = true;
            txt_num_usuario.Visible = true;
            txt_pass_usuario.Visible = true;
            label1.Visible = true;
            label2.Visible = true;
            label3.Visible = true;
            label4.Visible = true;
        }

        //RadioButton Eliminar
        private void RadioButton3_CheckedChanged(object sender, EventArgs e)
        {
            //Limpiar Casillas
            txt_nom_usuario.Clear();
            txt_num_usuario.Clear();
            txt_pass_usuario.Clear();
            //Activar Casillas
            txt_num_usuario.Enabled = false;
            txt_nom_usuario.Enabled = false;
            txt_pass_usuario.Enabled = false;
            cmbTipo_usuario.Enabled = false;
            cmbUsuario.Visible = true;
            //Activar Botones
            btnRegistrar.Visible = false;
            btnModificar.Visible = false;
            btnEliminar.Visible = true;
            cmbUsuario.Enabled = true;
            btnRefrescar.Visible = true;
            //Mostrar Textbox y Label
            cmbTipo_usuario.Visible = true;
            txt_nom_usuario.Visible = true;
            txt_num_usuario.Visible = true;
            txt_pass_usuario.Visible = true;
            label1.Visible = true;
            label2.Visible = true;
            label3.Visible = true;
            label4.Visible = true;
        }

        //Boton Agregar Usuario
        private void BtnRegistrar_Click(object sender, EventArgs e)
        {
            if (txt_nom_usuario.Text != "" && txt_num_usuario.Text != "" && txt_pass_usuario.Text != "" && cmbTipo_usuario.SelectedIndex > 0)
            {
                if (cn.Insertar_usuario(txt_num_usuario.Text, txt_nom_usuario.Text, txt_pass_usuario.Text, cmbTipo_usuario.Text))
                {
                    MessageBox.Show("Usuario Agregado Exitosamente");
                    //Limpiar las textbox
                    txt_nom_usuario.Clear();
                    txt_num_usuario.Clear();
                    txt_pass_usuario.Clear();
                }
                else
                {
                    MessageBox.Show("El usuario no se ha podido agregar");
                }
            }
            else {
                MessageBox.Show("Debe ingresar todos los datos");
            }
        }
        //Boton Modificar Usuario
        private void BtnModificar_Click(object sender, EventArgs e)
        {
            if (cn.Modificar_usuario(txt_num_usuario.Text, txt_nom_usuario.Text, txt_pass_usuario.Text, cmbTipo_usuario.Text))
            {
                MessageBox.Show("Se ha modificado el usuario Exitosamente");
            }
            else {
                MessageBox.Show("El usuario se ha podido agregar");
            }
        }
        //Botón Eliminar Usuario

        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            if (cn.Eliminar_usuario(txt_nom_usuario.Text))
            {
                MessageBox.Show("Usuario Eliminado Exitosamente");
            }
            else {
                MessageBox.Show("El usuario no se ha podido eliminar");
            }
        }

        //Funcion que hace que ComboBox Usuario llene los textbox
        private void CmbUsuario_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbUsuario.SelectedIndex > 0) {
                string[] valores = cn.Buscar_info_usuario(cmbUsuario.Text);
                txt_num_usuario.Text = valores[0];
                txt_nom_usuario.Text = valores[1];
                txt_pass_usuario.Text = valores[2];
                cmbTipo_usuario.Text = valores[3];
            }
        }

        private void BtnRefrescar_Click(object sender, EventArgs e)
        {
            frm_Usuarios usuarios = new frm_Usuarios();
            if (radioButton2.Checked) {
                this.Hide();
                usuarios.Show();
                radioButton2.Select();
            }
        }
    }
}
