﻿using System;
using System.Windows.Forms;

namespace RDJ
{
    static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Login());
            //Application.Run(new frm_Usuarios());
            //Application.Run(new frm_RP_General());
            //Application.Run(new frm_RP_Odonto());
        }
    }
}
