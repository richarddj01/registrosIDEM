﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace RDJ
{
    class Conexion
    {
        SqlConnection cn;
        SqlCommand cmd;
        SqlDataReader sdr;


        public Conexion() {
            try {
                cn = new SqlConnection("Data Source=DESKTOP-IJ06IBR;Initial Catalog=rdj;Integrated Security=True");
            }
            catch (Exception e) {
                MessageBox.Show(e.Message);
                MessageBox.Show("No se pudo conectar a la base de datos: " + e.ToString());
            }
        }

        //------------------------------------------------------------------------------------------------------
        //------------------------------------------------------------------------------------------------------
        //------------------------------------------frm_Usuarios------------------------------------------------
        //------------------------------------------------------------------------------------------------------
        //------------------------------------------------------------------------------------------------------

        //ComboBox tipo usuario (frm_Usuarios)
        public void Nombre_usuario(ComboBox nom_usuario) {
            nom_usuario.Items.Clear();
            cn.Open();
            cmd = new SqlCommand("select * from usuarios", cn);
            sdr = cmd.ExecuteReader();
            while (sdr.Read()) {
                nom_usuario.Items.Add(sdr[1].ToString());
            }
            cn.Close();
            nom_usuario.Items.Insert(0, "Seleccione Usuario");
            nom_usuario.SelectedIndex = 0;
        }
        //Insertar Datos Usuarios (frmUsuarios)
        public bool Insertar_usuario(string num_usuario, string nom_usuario, string pass_usuario, string tipo_usuario)
        {
            cn.Open();
            cmd = new SqlCommand("INSERT INTO usuarios VALUES ("+num_usuario+",'"+nom_usuario+"','"+pass_usuario+"','"+tipo_usuario+"')", cn);
            int filasafectadas = cmd.ExecuteNonQuery();
            cn.Close();
            if (filasafectadas > 0) return true;
            else return false;
        }
        //Eliminar Datos Usuarios (frmUsuarios)
        public bool Eliminar_usuario(string nom_usuario)
        {
            cn.Open();
            cmd = new SqlCommand("DELETE FROM usuarios where nombre_usuario = '"+nom_usuario+"'",cn);
            int filasafectadas = cmd.ExecuteNonQuery();
            cn.Close();
            if (filasafectadas > 0) return true;
            else return false;
        }
        //Modificar Datos Usuarios (frmUsuarios)
        public bool Modificar_usuario(string num_usuario, string nom_usuario, string pass_usuario, string tipo_usuario)
        {
            cn.Open();
            cmd = new SqlCommand("UPDATE usuarios set nombre_usuario = '" + nom_usuario + "', pass_usuario = '" + pass_usuario + "', tipo_usuario = '" + tipo_usuario + "' WHERE num_usuario = '" + num_usuario + "'", cn);
            int filasafectadas = cmd.ExecuteNonQuery();
            cn.Close();
            if (filasafectadas > 0) return true;
            else return false;
        }

        //Funcion que hace que la combobox usuario se conecte con la base de datos y obtenga valores
        //para luego llenar los textbox de la pantalla frmUsuarios
        public string[] Buscar_info_usuario(string nom_usuario) {
            cn.Open();
            cmd = new SqlCommand("SELECT * FROM usuarios where nombre_usuario = '" + nom_usuario + "'", cn);
            sdr = cmd.ExecuteReader();
            string[] resultado = null;
            while (sdr.Read()) {
                string[] valores = {
                    sdr[0].ToString(),
                    sdr[1].ToString(),
                    sdr[2].ToString(),
                    sdr[3].ToString()
                };
                resultado = valores;
            }
            cn.Close();
            return resultado;
        }

        //ComboBox Seleccionar Tipo de Usuario (FrmUsuarios)
        public void tipo_usuario(ComboBox tipo_usuario)
        {
            tipo_usuario.Items.Clear();
            cn.Open();
            cmd = new SqlCommand("select * from usuarios_tipo", cn);
            sdr = cmd.ExecuteReader();
            while (sdr.Read())
            {
                tipo_usuario.Items.Add(sdr[1].ToString());
            }
            cn.Close();
            tipo_usuario.Items.Insert(0, "   Seleccione Uno");
            tipo_usuario.SelectedIndex = 0;
        }

        //------------------------------------------------------------------------------------------------------
        //------------------------------------------------------------------------------------------------------
        //-----------------------------------------frm_RP_General-----------------------------------------------
        //------------------------------------------------------------------------------------------------------
        //------------------------------------------------------------------------------------------------------

        //Insertar datos en (frm_RP_General)
        public bool Insertar_MGeneral(string id, string identidad, string nombre, string apellido, string sexo, string nacimiento, string direccion, string telefono, string alergias)
        {
            cn.Open();
            cmd = new SqlCommand("INSERT INTO mg_registro VALUES (" + id + ",'" + identidad + "', '" + nombre + "','" + apellido + "', '" + sexo + "', '"+ nacimiento+"','"+direccion+"', '"+telefono+"', '"+alergias+"')", cn);
            int filasafectadas = cmd.ExecuteNonQuery();
            cn.Close();
            if (filasafectadas > 0) return true;
            else return false;
        }
        public bool Modificar_MGeneral(string id, string identidad, string nombre, string apellido, string sexo, string nacimiento, string direccion, string telefono, string alergias)
        {
            cn.Open();
            cmd = new SqlCommand("UPDATE mg_registro set id_rmg = " + id + ", nombre_rmg='" + nombre + "',apellido_rmg='" + apellido + "',sexo_rmg= '" + sexo + "', nacimiento_rmg = '" + nacimiento + "',direccion_rmg='" + direccion + "', telefono_rmg = '" + telefono + "', alergias_rmg = '" + alergias + "' where identidad_rmg = '"+identidad+"'", cn);
            int filasafectadas = cmd.ExecuteNonQuery();
            cn.Close();
            if (filasafectadas > 0) return true;
            else return false;
        }

        public string[] Buscar_RP_General(string identidad)
        {
            cn.Open();
            cmd = new SqlCommand("SELECT * FROM mg_registro where identidad_rmg = '" + identidad + "'", cn);
            sdr = cmd.ExecuteReader();
            string[] resultado = null;
            while (sdr.Read())
            {
                string[] valores = {
                    sdr[0].ToString(),
                    sdr[1].ToString(),
                    sdr[2].ToString(),
                    sdr[3].ToString(),
                    sdr[4].ToString(),
                    sdr[5].ToString(),
                    sdr[6].ToString(),
                    sdr[7].ToString(),
                    sdr[8].ToString()
                };
                resultado = valores;
            }
            cn.Close();
            return resultado;
        }

        public bool Eliminar_MGeneral(string identidad)
        {
            cn.Open();
            cmd = new SqlCommand("DELETE FROM mg_registro where identidad_rmg = '" + identidad + "'", cn);
            int filasafectadas = cmd.ExecuteNonQuery();
            cn.Close();
            if (filasafectadas > 0) return true;
            else return false;
        }
        //------------------------------------------------------------------------------------------------------
        //------------------------------------------------------------------------------------------------------
        //-----------------------------------------frm_RP_Odonto------------------------------------------------
        //------------------------------------------------------------------------------------------------------
        //------------------------------------------------------------------------------------------------------

        //Insertar datos en (frm_RP_General)
        public bool Insertar_Odonto(string id, string identidad, string nombre, string apellido, string sexo, string nacimiento, string direccion, string telefono, string alergias)
        {
            cn.Open();
            cmd = new SqlCommand("INSERT INTO odonto_registro VALUES (" + id + ",'" + identidad + "', '" + nombre + "','" + apellido + "', '" + sexo + "', '" + nacimiento + "','" + direccion + "', '" + telefono + "', '" + alergias + "')", cn);
            int filasafectadas = cmd.ExecuteNonQuery();
            cn.Close();
            if (filasafectadas > 0) return true;
            else return false;
        }
        public bool Modificar_Odonto(string id, string identidad, string nombre, string apellido, string sexo, string nacimiento, string direccion, string telefono, string alergias)
        {
            cn.Open();
            cmd = new SqlCommand("UPDATE odonto_registro set id_od = " + id + ", nombre_od='" + nombre + "',apellido_od='" + apellido + "',sexo_od= '" + sexo + "', nacimiento_od = '" + nacimiento + "',direccion_od='" + direccion + "', telefono_od = '" + telefono + "', alergias_od = '" + alergias + "' where identidad_od = '" + identidad + "'", cn);
            int filasafectadas = cmd.ExecuteNonQuery();
            cn.Close();
            if (filasafectadas > 0) return true;
            else return false;
        }

        public string[] Buscar_RP_Odonto(string identidad)
        {
            cn.Open();
            cmd = new SqlCommand("SELECT * FROM odonto_registro where identidad_od = '" + identidad + "'", cn);
            sdr = cmd.ExecuteReader();
            string[] resultado = null;
            while (sdr.Read())
            {
                string[] valores = {
                    sdr[0].ToString(),
                    sdr[1].ToString(),
                    sdr[2].ToString(),
                    sdr[3].ToString(),
                    sdr[4].ToString(),
                    sdr[5].ToString(),
                    sdr[6].ToString(),
                    sdr[7].ToString(),
                    sdr[8].ToString()
                };
                resultado = valores;
            }
            cn.Close();
            return resultado;
        }

        public bool Eliminar_Odonto(string identidad)
        {
            cn.Open();
            cmd = new SqlCommand("DELETE FROM odonto_registro where identidad_od = '" + identidad + "'", cn);
            int filasafectadas = cmd.ExecuteNonQuery();
            cn.Close();
            if (filasafectadas > 0) return true;
            else return false;
        }
    }
}
